package com.heareasy.model;

public class DeviceListModel {
    String name;

    public DeviceListModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
