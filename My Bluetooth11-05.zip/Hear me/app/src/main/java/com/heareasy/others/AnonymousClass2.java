package com.heareasy.others;

import android.telephony.PhoneStateListener;

public class AnonymousClass2 extends PhoneStateListener {
}
